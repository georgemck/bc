<?php
class Contact_Model_Message extends Zend_Db_Table_Abstract 
{
    
}
?>