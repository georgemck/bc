
-- mysql -u root -p     #passwordx

CREATE DATABASE zf_cms;


-- create user and grant permissions
CREATE USER 'student'@'localhost' IDENTIFIED BY 'passwordx';

GRANT SELECT,INSERT,UPDATE,DELETE ON zf_cms.* TO 'student'@'localhost';

-- view all users
-- select User, Host, Password from mysql.user;


-- select the database to use

use zf_cms;


SET FOREIGN_KEY_CHECKS=0;


-- ----------------------------
-- Table structure for bugs
-- ----------------------------
DROP TABLE IF EXISTS `bugs`;

CREATE TABLE `bugs` (
`id` int(11) unsigned NOT NULL AUTO_INCREMENT,
`author` varchar(250) DEFAULT NULL,
`email` varchar(250) DEFAULT NULL,
`date` int(11) DEFAULT NULL,
`url` varchar(250) DEFAULT NULL,
`description` text,
`priority` varchar(50) DEFAULT NULL,
`status` varchar(50) DEFAULT NULL,
PRIMARY KEY (`id`)
);

-- show tables;

-- select * from bugs;
