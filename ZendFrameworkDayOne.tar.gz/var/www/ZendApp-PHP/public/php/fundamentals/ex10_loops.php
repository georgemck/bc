<?php

// This file illustrates how loops are used
// to repeatedly execute a block of code. The
// code itself does not change each time the
// loop runs through it, but the values of variables
// inside the code do change.

?>

<html><head><title>Exercise 10: While- and For- Loops</title></head>
<body>
<h1>Exercise 10: While- and For- Loops</h1>

<h3>While Loops:</h3>

<?php
	$num=3;
	
	while ($num < 10){
		$num=rand(3,15);
		print($num."<br>");	
	}
		
	//this while could be written as aq for loop as it uses acounter
	
	$angle = 0;
	while($angle < pi()*2){
	    $width = abs(floor(sin($angle)*300));
	    print("<hr width=$width>\n");
	    $angle = $angle + 0.2;
	}

	print("<hr>");
	
	//rewriting the while as afor loop
	
	for($angle = 0; $angle < pi()*2; $angle = $angle + 0.2){
		    $width = abs(floor(sin($angle)*300));	
		    print("<hr width=$width>");
	}
?>
	<br><h3>For Loops:</h3>

<?php

	for($x=0; $x<10; $x=$x+1){
		    print($x . "<br>");
	}
	print("<hr>");
	
	// $students[0]="Cynthia";
	// $students[1]="Alex";
	// $students[2]="Graham";
	// $students[3]="Rachel";
	
	$students=array("Cynthia","Alex","Graham","Rachel");

	for($x=0; $x<4; $x=$x+1){
		    print($students[$x] . "<br>");
	}
	
	
	print("<hr>");


// Note that you can nest one loop within another.

	for($row = 0; $row < 10; $row++){
	    print("row $row: ");
	    for($column = 0; $column < 20; $column++){
	        if   (rand(0,1) == 1) {
	        	print "_";
			}
	        else{
	        	print "|";
			}
	    }
	    print("<br>");
	}
	
?>
</body>
</html>