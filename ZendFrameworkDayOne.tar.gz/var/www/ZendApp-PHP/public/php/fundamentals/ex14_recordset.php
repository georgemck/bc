<?php

// This file illustrates how to loop
// through the rows in a recordset
// retrieved from a MySQL database

$host     = "localhost";
$user     = "root";
$password = "passwordx";
$database = "northwind";


$link = mysqli_connect($host, $user  , $password, $database);

if (!$link) {
    die('Connect Error (' . mysqli_connect_errno() . ') '
            . mysqli_connect_error());
}

$recordset = mysqli_query($link, "SELECT * FROM $database.Shippers");
if($recordset == false) { die('Connect Error (' . mysqli_connect_errno() . ') '
            . mysqli_connect_error());}
?>

<html>
<body>
<h1>Exercise 14: Retrieving a Recordset</h1>

<pre>
<?php
while($row = mysqli_fetch_assoc($recordset))
	{
		print $row["CompanyName"] . str_repeat("_", 50 - strlen($row["CompanyName"])) . $row["Phone"] . "\n";
	}
?>
</pre>

</body>
</html>