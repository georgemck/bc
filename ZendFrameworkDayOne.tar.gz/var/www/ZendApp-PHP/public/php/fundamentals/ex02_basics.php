<html>
<body>

<h1>Exercise 2: PHP Basics</h1>

<?php
// Comments:
// Author: Stephen Fraga, sfraga@academyx.com, 415-392-8024
// File: ex02_basics.php
// Purpose: This file illustrates comments and basic output
// Date Created: 12/1/2001
/*
Modifications:
	12/15/2001 - added more comments -SF
	1/5/2002   - created multi-line comments -SF
	2/9/2002   - added more print examples -SF
*/
print("Hello there! ");
print("What a <b>nice</b> day.");
?>

<br><hr>

<?php
print("2 + 2");
print(" is ");
print(2 + 2);
print("<br><hr>");

print("goodbye");


?>

</body>
</html>
