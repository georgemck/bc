<?php

// This file illustrates how to loop
// through the rows in a recordset
// retrieved from a MySQL database

$host     = "localhost";
$user     = "root";
$password = "passwordx";
$database = "northwind";

mysql_connect($host, $user, $password) or die(mysql_error());
mysql_select_db($database)             or die(mysql_error());

$recordset = mysql_query("SELECT * FROM Orders");
if($recordset == false) {die(mysql_error());}

function fix($xml_word)
{
// This function replaces umlauts, accented characters, tildes and
// other non-XML-compliant characters with their &#xx; equivalents.
// Without it, the Internet Explorer display of the XML would break.
if(htmlentities($xml_word) != $xml_word)
        {
        $fixed_xml_word = "";
        for($x = 0; $x <= strlen($xml_word); $x++)
                {
                $letter = substr($xml_word,$x,1);
                if(htmlentities($letter) != $letter) { $fixed_xml_word .= '&#' . ord($letter) . ';'; }
                else { $fixed_xml_word .= $letter; }
                }
        return($fixed_xml_word);
        }
else
        {
        return($xml_word);
        }
}
?>

<html>
<body>
<h1>Exercise 17: Working with Files</h1>

<?php

$xml = file_get_contents("ex17_files2.xml");

print "Current file size: " . strlen($xml) . "<br>";
print "First 500 chars:   " . htmlentities(substr($xml,0,500)) . "<br>";

$data = "";
$data = $data . '<?xml version="1.0" ?>' . "\r\n";
$data = $data . "<allorders>" . "\r\n";

while($row = mysql_fetch_assoc($recordset))
        {
        $data = $data . '<order id="' . $row["OrderID"] . '">'                 . "\r\n";
        $data = $data . "<date>" .      $row["OrderDate"]       . "</date>"    . "\r\n";
        $data = $data . "<city>" .      fix($row["ShipCity"])   . "</city>"    . "\r\n";
        $data = $data . "<country>"   . $row["ShipCountry"]     . "</country>" . "\r\n";
        $data = $data . '</order>' . "\r\n";
        }

$data = $data . "</allorders>" . "\r\n";

file_put_contents("c:/temp/ex17_files2.xml", $data);


$html = file_get_contents("http://www.tired.com");
print $html;
?>

</body>
</html>