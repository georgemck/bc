<p align="center">
	<a href="http://www.phpfreaks.com">www.phpfreaks.com</a>
	|
	<a href="http://www.php.net">www.php.net</a>
	|
	<a href="http://www.phpbuilder.com">www.phpbuilder.com</a>
	|
	<a href="http://www.experts-exchange.com/Web/Web_Languages/PHP/">www.experts-exchange.com</a>

</p>
