<?php

// This file illustrates how to extract named input tags on a web
// page into variables in PHP. For example, after the extract(),
// <input type="text" name="age"> results in $age on the
// page that is submitted to
//phpinfo();
extract($_REQUEST);

//when the function extract() is passed an associative arry 
//it creates a seperate variable 
//for each cell of the assocoated array.
//variable name is the key (input tag name) starting with $
//variable value is the value of that cell of the array


$fullname  = $firstname . " " . $lastname;
$longevity = 100 - $age;

?>
<html>

<body bgcolor="<?= $favorite_color ?>">

<h1>Exercise 8: Form Results</h1>

Thanks for your input, <?= $fullname ?>.<br>
You will live another <?= $longevity ?> years.<br><hr>

First Name: <b><?= $firstname ?></b><br>
Last Name:  <b><?= $lastname  ?></b><br>
Age:        <b><?= $age       ?></b><br>

</body>
</html>
