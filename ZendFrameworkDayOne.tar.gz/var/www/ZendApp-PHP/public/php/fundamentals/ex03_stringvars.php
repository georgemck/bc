<?php

// This file illustrates the creation and concatenation
// of string variables. String variables are words or
// sentences.

$ceo    = "Owen Smith";
$prez   = "Nancy Jones";
$cfo    = $prez;
$intern = $ceo . ", Jr.";
?>
<html>
<body>

<h1>Exercise 3: String Variables</h1>

<?php
print("The CEO is: ");
print($ceo);
print("<br>");

print("The President is: " . $prez . "<br>");
print("The CFO is: $cfo<br>");
print("The intern is $intern<br>");
?>

</body>
</html>
