<?php
// This file illustrates the most useful
// miscellaneous features of PHP. The user
// emails themselves a message.
//
// The page submits to itself. It sends the
// email if there are no errors, then redirects
// to a "thank-you page". If, however the
// input tag is missing (not submitted) or
// if there were errors in the email address,
// the page displays the form for input.

extract($_REQUEST);

if(!isset($to_email)){
	$to_email='';
	$subject='';
	$message='';	
}

if(isset($myButton)){
	
		$error="";
	
    	if(strpos($to_email,  "@") == false){
    		$error="error occured";
?>
        	<font color="red">Invalid email</font><br>
<?php
    	}
    	if($subject == ""){
      		$error="error occured";

?>
       		<font color="red">You must provide a subject</font>
<?php
    	}
    	if ($error==""){
			date_default_timezone_set('America/Los_Angeles') ;	
			$mail_body  = $message . "\r\n" . "Sent at " . date("Y-m-d H:i:s");
			$from_email = "info@academyx.com";
			$to_email   = trim($to_email);
			$unix_from  = "From: $from_email\r\n"; // unix only    -- from: address
			
			ini_set("sendmail_from", $from_email); // windows only -- from: address
			ini_set("SMTP", "smtp.academyx.com");  // windows only -- mail server IP
			
			mail($to_email, $subject, $mail_body, $unix_from);
			header("Location: ex11_thankyou.php");
     	}
}
?>

<h1>Exercise 11: Send Someone an Email (misc.)</h1>

<form action="<?= $_SERVER['PHP_SELF'] ?>">
	
Email:   <input type="text" name="to_email" value="<?= $to_email ?>"><br>
Subject: <input type="text" name="subject"  value="<?= $subject ?>"><br>
Message: <textarea name="message" ><?= $message ?></textarea><br>

       
  <input type="submit" value="send" name="myButton"><br>


</form>

<?php
	include("ex11_footer.php");
?>

</body>
</html>