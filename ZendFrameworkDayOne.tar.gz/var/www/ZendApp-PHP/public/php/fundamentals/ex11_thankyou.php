<html><head><title>Exercise 11: Miscellaneous Useful Stuff</title></head>
<body>
<h1>Exercise 11: Miscellaneous Useful Stuff</h1>

The email has been sent.

<?php include("ex11_footer.php"); ?>
</body>
</html>