<html>
<body>
<h1>Exercise 13: Connecting to MySQL</h1>

<?php

$host     = "localhost";
$user     = "root";
$password = "passwordx";
$database = "northwind";

$link = mysqli_connect($host, $user  , $password, $database);

if (!$link) {
    die('Connect Error (' . mysqli_connect_errno() . ') '
            . mysqli_connect_error());
}

print "Connected to '$host' as '$user', password '$password', database $database<hr>";

$biz = "Delivery by JoeX";
$num = "415-392-8024X";
$sql = "INSERT INTO $database.Shippers (CompanyName, Phone) " .
       "VALUES ('$biz','$num')";
	   

mysqli_query($link,$sql) or die(mysqli_error());
print "Inserted '$biz'<hr>";

?>
</body>
</html>