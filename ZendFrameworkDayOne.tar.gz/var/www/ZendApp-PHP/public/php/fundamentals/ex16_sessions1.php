<?php

	if(isset($_GET["background"])){
		//phpinfo();
		ini_set("session.save_path","C:/temp");
		session_start();
		$_SESSION["bkg"] = $_GET["background"];
		$_SESSION["txt"] = $_GET["text"];
		print '<a href="ex16_sessions2.php">Click</a> to see your preferences.';
		exit();
	}
?>

<html>
<body>
<h1>Exercise 16: Sessions</h1>

<form action="<?=$_SERVER['PHP_SELF']?>">


Favorite background color:	<select name="background">
								<option>lightblue</option>
								<option>pink</option>
								<option>orange</option>
								<option>lightgreen</option>
							</select>
<br>
Favorite text color:	<select name="text">
								<option>darkblue</option>
								<option>darkred</option>
								<option>green</option>
								<option>blue</option>
							</select>

<input type="Submit" value="save preferences">

</form>