<html>
<body>
<h1>Exercise 5: String Functions</h1>
<?php



// This file illustrates the application of string manipulation
// functions to string variables. These are some of the most
// common functions used in typical PHP scripts.

$email      = "jsmith@ibm.com";
$bigger     = strtoupper($email);
$email_len  = strlen($email);
$at_pos     = strpos($email, "@");

$user       = substr($email, 0, $at_pos);

$company    = substr($email, $at_pos+1, strpos($email,".com")-$at_pos-1);

//            substr("jsmith@ibm.com",7,3)

$schoolify  = str_replace(".com",".edu",$email);
$monopoly   = str_repeat($company, 10);
?>

email:            <?= "$email <br>" ?>
emphatic:         <?= "$bigger <br>" ?>
# chars in email: <?= "$email_len <br>" ?>
Position of @:    <?= "$at_pos <br>" ?>
User:             <?= "$user <br>" ?>
Company:          <?= "$company <br>" ?>
Schoolify:        <?= "$schoolify <br>" ?>
Monopoly:         <?= $monopoly ?>

</body></html>
