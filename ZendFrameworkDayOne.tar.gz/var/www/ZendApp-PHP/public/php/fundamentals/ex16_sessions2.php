<?php
ini_set("session.save_path","C:/temp");
session_start();
$body = "<body bgcolor=" . $_SESSION["bkg"] . " text=" . $_SESSION["txt"] . ">";
print( htmlspecialchars($body));

?>

<html>
<?=$body?>

<h1>Exercise 16: Sessions, Part Two: Retrieval</h1>

This illustrates how to retrieve session data.

<hr>

<a href="ex16_sessions1.php">Change</a> your preferences.

</body>
</html>
