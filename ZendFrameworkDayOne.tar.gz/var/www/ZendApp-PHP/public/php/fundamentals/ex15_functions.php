<html>
<body>
<h1>Exercise 15: Functions and Global Variables</h1>
<?php
$host     = "localhost";
$user     = "root";
$password = "passwordx";
$database = "northwind";
$link = mysqli_connect($host, $user  , $password, $database);

if (!$link) {
    die('Connect Error (' . mysqli_connect_errno() . ') '
            . mysqli_connect_error());
}


$all_rows = 0;

function showtable($table, $color){  //parameters
		global $link;
		$recordset = mysqli_query($link, "SELECT * FROM $table");
		if($recordset == false) { die('Connect Error (' . mysqli_connect_errno() . ') '
            . mysqli_connect_error());}

		print( mysqli_field_count($link).'<br>');
		
		print(mysqli_fetch_field_direct( $recordset, 0)->name);
		
        global $all_rows;
        $rows_displayed = 0;
        $toggle = 1;
        print "<table>";
		
        while($row = mysqli_fetch_row($recordset)){
                $toggle = $toggle * -1;
                if($toggle == 1){
                	print "<tr bgcolor=$color>";
                }
                else{
                	print "<tr bgcolor=white>";
                }
                print "<td>" . $row[0] . "</td>";
                print "<td>" . $row[1] . "</td>";
                print "<td>" . $row[2] . "</td>";
                print "</tr>\n";
                $rows_displayed = $rows_displayed + 1;
                $all_rows = $all_rows + 1;
        }
        print "</table>";
        return($rows_displayed);
}

$rows = showtable("Shippers","lightblue");  //arguments
print "<b>$rows in table, $all_rows displayed so far</b><hr>";

$rows = showtable("Categories","yellow");
print "<b>$rows in table, $all_rows displayed so far</b><hr>";

$rows = showtable("Products","pink");
print "<b>$rows in table, $all_rows displayed so far</b><hr>";
?>

</body>
</html>
