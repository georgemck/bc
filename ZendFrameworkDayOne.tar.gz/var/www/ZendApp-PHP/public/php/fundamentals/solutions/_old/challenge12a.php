<html><head><title>Exercise 9: Conditionals Input</title></head>
<body>
<h1>ch 12</h1>

<pre>

	<form action="challenge12b.php" method="get">


	Month of birth:    <input type="text" name="month" size="10">
			     <input type="submit" value="Horoscope, please">
	</form>

</pre>
</body>
</html>
