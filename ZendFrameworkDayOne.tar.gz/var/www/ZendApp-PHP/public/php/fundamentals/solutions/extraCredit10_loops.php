
<html><head><title>Ch 10:  For- Loops</title></head>
<body>
<h1>Extra Credit 10: probability</h1>

<?php
$success=0;
for($x=0; $x<5000; $x++) {
    		$dice1=rand(1,6);
		$dice2=rand(1,6);

		if($dice1+$dice2==7 || $dice1+$dice2==11) {
			$success++;
		}
    }

	print("success rate ".$success/5000);
?>
</body>
</html>