<?php

// This file illustrates the creation and manipulation
// of numeric variables. Numeric variables can be integers or
// real numbers.

$sales      = 190000;
$exp_rental =  25000;
$exp_salary =  37500;
$exp_supply =    410;
$exp_total          = $exp_rental + $exp_salary + $exp_supply;
$operating_income   = $sales - $exp_total;
$net_income         = $operating_income * 0.60;
?>
<html>
<body>

<h1>Exercise 4: Numeric Variables</h1>




Sales:       <?= $sales ?> dollars <br>

Expenses:       <?= $exp_total  ?> dollars <br>

------<br>

Income:    <?=   $sales - $exp_total ?> dollars


</body>
</html>
