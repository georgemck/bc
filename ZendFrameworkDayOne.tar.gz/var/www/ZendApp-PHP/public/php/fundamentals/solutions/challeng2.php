<html>
<head>
	<title>ch 2</title>
</head>

<body>

<h1>Challenge 2</h1>
<?php
/*
print("<table cellspacing="25">......
the extra quotes do not work without the backslash (\ escape character)
*/

print("<table cellspacing=\"25\" border='1'>
	<tr style=\"background-color:orange\">
	<td>rewqewqewqew</td><td>qweqwe</td></tr>
	<tr><td>qweqwe</td><td>qwreqwerewq</td></tr>
</table>");

print('<table cellspacing="25">
	<tr style="background-color:orange">
	<td>rewqewqewqew</td><td>qweqwe</td></tr>
	<tr><td>qweqwe</td><td>qwreqwerewq</td></tr>
</table>');

?>


</body>
</html>
