
<html><head><title></title></head>
<body>
<h1>12 ex cr loop array</h1>



<?php
/*

$countAr[0]="Israel";
$countAr[1]="England";
$countAr[2]="India";
*/

$countAr=array("Israel","England","India");

$len=sizeof($countAr);

for($x=0; $x < $len; $x++)
    {
    print("I lived in $countAr[$x]<br>");
 }

?>
</body>
</html>