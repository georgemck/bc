<html><head><title>Exercise 9: Conditionals Input</title></head>
<body>
<h1>Challenge 9: 3 month Horoscope</h1>

<pre>
	<form action="ex09_if_new_challenge.php" method="get">

	Month: <input type="text" name="month"> (available Jan, Feb, Mar)
	Full Name:    <input type="text" name="fullName" >
			     <input type="submit" value="Horoscope, please">
	</form>
</pre>


<?php

	extract($_REQUEST);

	if (isset($month)) {



		$month_validation = "ok so far";
		$name_validation = "ok so far";

		if($fullName ==''){
			$name_validation = "You must enter a name";
		}

		if($month == "Jan"){
			
			$horoscope='You will be very cold';
		}
		elseif($month == "Feb"){
			$horoscope='You will see the cherries bloom';
		}
		elseif($month == "Mar"){
			$horoscope='You will see more blooming flowers';
		}
		else{
			$month_validation = "Please enter an appropriate month";
		}


		if($month_validation == "ok so far" && $name_validation == "ok so far") {
?>		
		  <?= $fullName . ", " .$horoscope ?>
			

<?php
		}
		else{
			if ($month_validation != "ok so far"){
?>
				<font color="red"><?= $month_validation ?></font>
<?php
			}
			if ($name_validation != "ok so far"){
?>
				<br>
				<font color="red"><?= $name_validation ?></font>
<?php
			}
		}
	}
?>


</body>
</html>
