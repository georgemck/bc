<html>
<body>

<form action="<?= $_SERVER['PHP_SELF'] ?>" method="get">


  	Month of birth:    <input type="text" name="month" size="10">
  			     <input type="submit" value="Horoscope, please">
  	</form>

<?php

$horAr["january"]="you will feel cold";
$horAr["april"]="you will see flowers bloom";
$horAr["july"]="you will be independent";


if (isset($_REQUEST["month"])){

	print("<hr>".$horAr[$_REQUEST["month"]]);
}

?>

</body>
</html>