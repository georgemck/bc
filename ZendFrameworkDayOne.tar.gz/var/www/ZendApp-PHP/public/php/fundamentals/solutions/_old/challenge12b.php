<?php
$horAr["january"]="you will feel cold";
$horAr["april"]="you will see flowers bloom";
$horAr["july"]="you will be independent";


//extract($_REQUEST);

print("<hr>".$horAr[$_REQUEST["month"]]);
 ?>
</body>
</html>
