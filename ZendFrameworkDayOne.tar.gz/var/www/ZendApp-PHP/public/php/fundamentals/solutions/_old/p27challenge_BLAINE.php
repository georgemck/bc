<?php
// Page 27 Challenge - Blaine Robertson
// Uses PDO which does not allow the table name to be parameterized

// For table list connection
$db2 = 'INFORMATION_SCHEMA';
$dsn2 = "mysql:dbname=$db2;host=$server";

// For Northwind connection
$db = 'northwind';
$dsn = "mysql:dbname=$db;host=$server";

// Common information for both connections
$server = 'localhost';
$username = 'root';
$password = 'passwordx';




try {
  $pdo = new PDO($dsn, $username, $password); // DB connection to northwind db
  $master = new PDO($dsn2, $username, $password); // DB connection to Information_schema db
} catch (PDOException $e) {
  echo 'Connection failed: ' . $e->getMessage();
}

function getColumnNames($table, $color) {
  global $pdo;
  global $master;
  $table = trim($table); // Remove any white space on the sides

// Get the list of table names as a white list of possibilities
  $sql = "SELECT TABLE_NAME
FROM INFORMATION_SCHEMA.TABLES
WHERE TABLE_TYPE = 'BASE TABLE' AND TABLE_SCHEMA='northwind'";
  $stmt2 = $master->prepare($sql);
  $stmt2->execute();
  while ($row = $stmt2->fetch(PDO::FETCH_ASSOC)) {
    foreach ($row as $column) {
      $tablelist[] = $column;
    }
  }
  $stmt2->closeCursor();

// this checks the table name against the master list of table names in the db 
// - keeps a bogus table name from being accepted
  if (in_array($table, $tablelist)) {
    try {
      $sql = "DESCRIBE $table";
      $stmt = $pdo->prepare($sql);
      $stmt->execute();
      while ($row = $stmt->fetch(PDO::FETCH_ASSOC)) {
        $table_fields[] = $row['Field'];
      }
      $stmt->closeCursor();
    } catch (PDOException $e) {
      echo 'Error in function';
    }
// Build the table of column names from the table
    $fieldlist = '<h2>' . $table . ' Table Fields</h2>';
    $fieldlist .= '<p>Fields in table is: '.count($table_fields).'</p>';
    $fieldlist .= '<table style="background-color:' . $color . '">';
    $fieldlist .= '<tr>';
    foreach ($table_fields as $column) {
      $fieldlist .= "<td>$column</td>";
    }
    $fieldlist .= '</tr></table>';
    return $fieldlist;
  } else {
    return 'Sorry, the table <i>'.$table .'</i> does not exist';
  }
}

// end of function
?>
<!DOCTYPE html>
<html>
  <head>
    <meta charset="UTF-8">
    <title>Page 27 Challenge</title>
  </head>
  <body>
	<h1>Page 27 Challenge</h1>
    <?php
    echo '<p>' . getColumnNames('customers', 'pink') . '</p>';
    echo '<p>' . getColumnNames('employees', 'salmon') . '</p>';
    echo '<p>' . getColumnNames('orders', 'aqua') . '</p>';
    echo '<p>' . getColumnNames('gibberish', 'lightgreen') . '</p>';
    ?>
  </body>
</html>