<?php
$slautation    = "Miz";
$firstName   = "Nancy";
$lastName    = "Jones";

?>
<html>
<body>

<h1>Challenge 3: String Variables</h1>

<?php
print("Hello $slautation $firstName  $lastName !");

//extra credit
print("<table cellspacing=\"25\">
	<tr style=\"background-color:orange\">
	<td>salutation</td><td>$slautation</td></tr>
	<tr><td>First Name</td><td>$firstName</td></tr>
	<tr><td>Last Name</td><td>$lastName</td></tr>
</table>")

?>



</body>
</html>
