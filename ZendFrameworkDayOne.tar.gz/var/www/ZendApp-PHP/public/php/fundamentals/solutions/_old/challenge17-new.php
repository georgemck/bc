<html>
<body>

<h1>challenge 17</h1>

<form action="<?= $_SERVER['PHP_SELF']?>" method="get">

<pre>
Name:     <input type="text" name="fullName">


				    <input type="submit" value="Send!">
</pre>

</form>


<?php



if(isset($_REQUEST['fullName'])){

	file_put_contents("c:/temp/challenge17b.txt", $_REQUEST['fullName']."\n",FILE_APPEND);

	$fileContent=file_get_contents("c:/temp/challenge17b.txt");

	print("strpos function: " . strpos($fileContent,"\n")."<br>");

	$fileContent = str_replace("\n" , "<br>", $fileContent);

	print($fileContent);
}


?>


</body>
</html>
