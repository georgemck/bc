<html>
<head>
<title>extra credit  9</title>
</head>

<body>

<h1>Extra Credit 9</h1>


		<form action="extraCredit9_if1.php" method="get">
			     	<input type="hidden" name ="submit" value="submitted">
				     <input type="submit" value="throw both dice" >
		</form>


<?php
	//$submit="rrr";
	extract($_REQUEST);

	if (isset($submit))  {
			$dice1=rand(1,6);
			print("dice 1 is:  ".$dice1."<br>");
			$dice2=rand(1,6);
			print("dice 2  is:  ".$dice2."<br>");

			if($dice1+$dice2==7 || $dice1+$dice2==11) {
				print ("YOU WIN!!!!");
			}
	}
	else{
			print("not submitted <br >");
	}
?>



<br>

</body>
</html>
