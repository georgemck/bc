<html>
<body>
<h1>Challenge 5: String Functions</h1>
<?php



$first      = "Barack";
$last     = "Obama";

// the most concise and fastest to execute
print(strtolower(substr($first,0,1).$last));



/*
$initial=substr($first,0,1);
$username=$initial.$last;
$usernameLowercase=strtolower($username);
print($usernameLowercase);
*/
?>
<br>
<?=strtolower(substr($first,0,1).$last)?>



</body></html>
