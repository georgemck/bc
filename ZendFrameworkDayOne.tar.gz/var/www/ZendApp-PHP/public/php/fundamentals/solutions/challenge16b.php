<?php
	ini_set("session.save_path","C:/temp");
	session_start();
	
	if ($_SESSION["authorized"]== "yes") {
	$host     = "localhost";
	$user     = "root";
	$password = "passwordx";
	$database = "northwind";

	$link = mysqli_connect($host, $user  , $password, $database);

	if (!$link) {
	   die('Connect Error (' . mysqli_connect_errno() . ') '
	           . mysqli_connect_error());
	}

	print("Orders for customer: " . $_SESSION["cusName"]  . " with id: " .  $_SESSION["ID"] . "<hr>");

	$recordset = 
	mysqli_query($link, "SELECT OrderDate FROM $database.Orders WHERE CustomerID='".  $_SESSION['ID'] . "'");
	if($recordset == false) { die('Connect Error (' . mysqli_connect_errno() . ') '
	            . mysqli_connect_error());}

	while($row = mysqli_fetch_assoc($recordset)) {
			print ($row["OrderDate"] . " order<br>");
	}
}
?>