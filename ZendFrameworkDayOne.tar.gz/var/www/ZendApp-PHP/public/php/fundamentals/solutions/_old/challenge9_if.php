<html><head><title>Exercise 9: Conditionals Input</title></head>
<body>
<h1>Ch 9: Conditionals Input</h1>

<pre>

	<form action="challenge9_if.php" method="get">


	Month of birth:    <input type="text" name="month" size="10">
			     <input type="submit" value="Horoscope, please">
	</form>

</pre>

<?php

extract($_REQUEST);

if(isset($month)){

	if($month== "january"){
?>
		You will feel cold
<?php
	}
	elseif($month== "april"){
?>
		You will see flowers bloom
<?php
	}
	elseif($month== "july"){
?>
	You will be independent
<?php
	}
	else
	{
?>
		No such month!!!!!
<?php
	}
}
 ?>


</body>
</html>
