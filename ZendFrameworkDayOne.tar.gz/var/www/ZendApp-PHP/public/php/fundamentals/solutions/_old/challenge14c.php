<?php
$host     = "localhost";
$user     = "root";
$password = "passwordx";
$database = "northwind";
?>
<html>
<body>
<h1>ch 14 c</h1>

<?php
extract($_REQUEST);

mysql_connect($host, $user, $password) or die(mysql_error());
print "Orders for company with customer id $comId<hr>";

mysql_select_db($database) or die(mysql_error());
$recordset = mysql_query("SELECT OrderDate, CustomerID FROM Orders WHERE CustomerID='$comId'");
if($recordset == false) {die(mysql_error());}

while($row = mysql_fetch_assoc($recordset)) {
	//if ($row["CustomerID"]==$comId) {
		print ($row["OrderDate"] . " order<br>");
		//}
}
?>

</body>
</html>