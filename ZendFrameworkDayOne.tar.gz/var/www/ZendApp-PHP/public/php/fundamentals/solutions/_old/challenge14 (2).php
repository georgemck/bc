
<form action='<?=$_SERVER["PHP_SELF"]?>' method="get">

	Enter a letter    <input type="text" name="letter">

			  <input type="submit" value="Send!">


	</form>



<?php



$host     = "localhost";
$user     = "root";
$password = "passwordx";
$database = "northwind";
?>
<html>
<body>
<h1>challenge 21 b</h1>

<?php
extract($_REQUEST);
if(isset($letter)){
	$link = mysqli_connect($host, $user  , $password, $database);

	if (!$link) {
	    die('Connect Error (' . mysqli_connect_errno() . ') '
	            . mysqli_connect_error());
	}

	$recordset = mysqli_query($link, "SELECT CompanyName, CustomerID FROM $database.Customers
	WHERE CompanyName LIKE '$letter%'");

	if($recordset == false) { die('Connect Error (' . mysqli_connect_errno() . ') '
            . mysqli_connect_error());}






	while($row = mysqli_fetch_assoc($recordset)) {
		print ("<a href='challenge14c.php?comId=" . $row["CustomerID"] . "&compName=" .$row["CompanyName"] .
		"' >" . $row["CompanyName"] . "</a><br>");

	}
}
?>




</body>
</html>