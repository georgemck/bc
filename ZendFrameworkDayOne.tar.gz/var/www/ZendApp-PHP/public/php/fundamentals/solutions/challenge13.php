
<h1>Exercise 13: Connecting to MySQL</h1>

<form action="<?=$_SERVER["PHP_SELF"]?>" method="get">


	Name:     <input type="text" name="biz">
	<br>
	Number:      <input type="text" name="num">
	<br>
	<input type="submit" value="Send!">
	<br>
</form>

<?php

$host     = "localhost";
$user     = "root";
$password = "passwordx";
$database = "northwind";


if (isset($_REQUEST['biz'])) {
	
	print "Connected to '$host' as '$user', password '$password'<hr>";

	$link = mysqli_connect($host, $user  , $password, $database);

	if (!$link) {
	    die('Connect Error (' . mysqli_connect_errno() . ') '
	            . mysqli_connect_error());
}
	$sql = "INSERT INTO Shippers (CompanyName, Phone) " .
	       "VALUES ('"  .  $_REQUEST['biz']  . "','"  .$_REQUEST['num'] . "')";

	mysqli_query($link, $sql) or die(mysqli_error());
	print("Inserted " . $_REQUEST['biz'] .  " and " . $_REQUEST['num'] . "<hr>");
}
?>




</body>
</html>