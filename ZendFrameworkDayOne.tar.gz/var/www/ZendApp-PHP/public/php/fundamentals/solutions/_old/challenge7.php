<html>
<body>
<h1>Ch 7: Escaping Special Characters</h1>

<pre>
<?php

print("See Spot run.<br>");
print("Spot cost big \$money.\n");
print("I like the name \t\t\"Spot\"\n");
print("\"You'll be C:\'ing me later\" said the blind man to his deaf dog \"Spot\".\n");
print('Spot doesn\'t map network drives from "C:\temp\" to \'\\\Canines\Dogs\' ');



?>
</pre>
</body></html>
