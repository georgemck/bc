
<form action='<?=$_SERVER["PHP_SELF"]?>' method="get">

	Enter a letter    <input type="text" name="letter">

			  <input type="submit" value="Send!">


	</form>



<?php



$host     = "localhost";
$user     = "root";
$password = "passwordx";
$database = "northwind";
?>
<html>
<body>
<h1>ch 21 b</h1>

<?php
extract($_REQUEST);
if(isset($letter)==true){
	mysql_connect($host, $user, $password) or die(mysql_error());
	print "Connected to '$host' as '$user', password '$password'<hr>";

	mysql_select_db($database) or die(mysql_error());
	print "Selected database '$database'<hr>";
	$letter=strtoupper($letter);
	$recordset = mysql_query
	("SELECT CompanyName, CustomerID FROM Customers WHERE CompanyName LIKE '$letter%'");

	if($recordset == false) {die(mysql_error());}

	while($row = mysql_fetch_assoc($recordset)) {
		print ("<a href='challenge14c.php?comId=" . $row["CustomerID"] .
		"' >go to " . $row["CompanyName"] . "</a><br>");

	}
}


/*
************AN ALTERNATIVE*************
$recordset = mysql_query("SELECT CompanyName, CustomerID FROM Customers");
if($recordset == false) {die(mysql_error());}

while($row = mysql_fetch_assoc($recordset)) {
	if (substr($row["CompanyName"],0,1)==$letter)  {
		print ("<a href='challenge21c.php?comId=" . $row["CustomerID"] . "' >go to " . $row["CompanyName"] . "</a><br>");
	}
}
*/
?>




</body>
</html>