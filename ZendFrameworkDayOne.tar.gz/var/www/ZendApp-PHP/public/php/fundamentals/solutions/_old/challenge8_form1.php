<html>
<body>
<h1>Ch 8: Form Input</h1>

<form action="challenge8_form2.php" method="get">

<pre>
	Company Name :     <input type="text" name="compName">
	Sales:      <input type="text" name="sales">
	Expenses: <input type="text" name="expenses">

				    <input type="submit" value="Send!">
</pre>

</form>


</body>
</html>
