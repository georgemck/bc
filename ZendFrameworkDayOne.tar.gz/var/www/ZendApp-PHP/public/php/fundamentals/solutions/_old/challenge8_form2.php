<?php
extract($_REQUEST);
?>

<html>

<body>

<h1>Ch 8: Form Results</h1>
<table>
	<tr><td>Company</td><td><?= $compName ?></td></tr>
	<tr><td>Sales</td><td><?= $sales ?></td></tr>
	<tr><td>Expenses</td><td><?= $expenses ?></td></tr>
	<tr><td>Net</td><td><?= $sales-$expenses ?></td></tr>
</table>


</body>
</html>
