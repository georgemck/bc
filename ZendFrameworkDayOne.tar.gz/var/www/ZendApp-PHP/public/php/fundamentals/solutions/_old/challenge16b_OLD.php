<?php


ini_set("session.save_path","C:/temp");
session_start();

if ($_SESSION["authorized"]== "yes") {

	$host     = "localhost";
	$user     = "root";
	$password = "passwordx";
	$database = "northwind";

	mysql_connect($host, $user, $password) or die(mysql_error());
	mysql_select_db($database) or die(mysql_error());


	print ("Orders for company with customer id " . $_SESSION['ID'] . "<hr>");

	$recordset = mysql_query("SELECT OrderDate, CustomerID FROM Orders WHERE CustomerID='".$_SESSION["ID"]."'");
	if($recordset == false) {die(mysql_error());}

	while($row = mysql_fetch_assoc($recordset)) {
		print ($row["OrderDate"] . " order<br>");
	}
}

?>