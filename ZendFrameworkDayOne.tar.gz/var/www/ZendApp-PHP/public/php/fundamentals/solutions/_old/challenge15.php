<?php


$host     = "localhost";
$user     = "root";
$password = "passwordx";
$database = "northwind";

$link = mysqli_connect($host, $user  , $password, $database);

if (!$link) {
    die('Connect Error (' . mysqli_connect_errno() . ') '
            . mysqli_connect_error());
}



function getnames($table, $color){
		global $link;
		$recordset = mysqli_query($link, "SELECT * FROM $table");
		if($recordset == false) { die('Connect Error (' . mysqli_connect_errno() . ') '
		          . mysqli_connect_error());}

		print("<table border=1><tr bgcolor='$color'>");
		$numFileds = mysqli_field_count($link);
		
		for($x=0; $x < $numFileds; $x++){
			print("<td>".mysqli_fetch_field_direct($recordset,$x)->name."</td>");
		}


		print("</tr></table>");
}

getnames("Shippers","orange");
getnames("Categories","lightblue");
getnames("Products","yellow");
?>


