<?php
	if(isset($_REQUEST['biz'])){
		ini_set("session.save_path","C:/temp");
		session_start();
		$host     = "localhost";
		$user     = "root";
		$password = "passwordx";
		$database = "northwind";
	
		$link = mysqli_connect($host, $user  , $password, $database);
	
		if (!$link) {
		    die('Connect Error (' . mysqli_connect_errno() . ') '
		            . mysqli_connect_error());
		}
	
		$recordset = mysqli_query($link, "SELECT * FROM Customers WHERE CompanyName='" . $_REQUEST['biz'] ."' and Phone='" . $_REQUEST['num'] . "'"
		);
	
		if($recordset == false) { die('Connect Error (' . mysqli_connect_errno() . ') '
	            . mysqli_connect_error());}
	
		if (mysqli_num_rows($recordset) >0){		
			$row = mysqli_fetch_assoc($recordset);
		
			$_SESSION["ID"]=$row["CustomerID"];
			$_SESSION["cusName"]=$row["CompanyName"];
			
			$_SESSION["authorized"]= "yes";
			
			header('Location: challenge16b.php');		
		}	
	}
?>
		<form action="<?=$PHP_SELF?>" method="get">
			Name:     <input type="text" name="biz">  use:   Around the Horn <br>
			Number:   <input type="text" name="num">  use: (171) 555-7788 <br>
					  <input type="submit" value="Send!">
		</form>

	</body>
</html>
