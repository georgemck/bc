
<h1>Exercise 13: Connecting to MySQL</h1>

<form action="<?=$_SERVER["PHP_SELF"]?>" method="get">
	Name:     <input type="text" name="biz"><br>
	Number:      <input type="text" name="num"><br>
	<input type="submit" value="Send!">
	<br>
</form>

<?php
$host     = "localhost";
$user     = "root";
$password = "passwordx";
$database = "northwind";


if (isset($_REQUEST['biz'])) {
	$link = mysqli_connect($host, $user  , $password, $database);

	if (!$link) {
	    die('Connect Error (' . mysqli_connect_errno() . ') ' . mysqli_connect_error());
	}
	print "Selected database '$database'<hr>";
	//ALTERNATIVE WAYS TO CONSTRUCT THE SQL CODE
  	// $biz= $_REQUEST['biz'];
  	// $num= $_REQUEST['num'];

  	//$sql = "INSERT INTO Shippers (CompanyName, Phone) VALUES (' $biz ',' $num');";

	//$sql = "INSERT INTO Shippers (CompanyName, Phone) VALUES (' $_REQUEST[biz] ',' $_REQUEST[num] ');";

	$sql = "INSERT INTO Shippers (CompanyName, Phone) VALUES ('" . $_REQUEST['biz'] . "','" . $_REQUEST['num'] . "');";

	print ("<br>$sql<br>");

	mysqli_query($link,$sql) or die(mysqli_error());
	print "Inserted " . $_REQUEST['biz'] .  " and " . $_REQUEST['num'] . "<hr>";
}
?>




</body>
</html>