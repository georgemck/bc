
<html><head><title>ECh 10: While- and For- Loops</title></head>
<body>
<h1>Exercise 10: While- and For- Loops</h1>



<?php
ini_set("error_reporting","E_ALL & ~E_NOTICE");

$abc="abcdefghijklmnopqrstuvwxyz";


for($x=0; $x<100; $x=$x+1)
    {
    $pw=$pw.substr($abc,rand(0,25),1);
    }
	print($pw );

?>
</body>
</html>