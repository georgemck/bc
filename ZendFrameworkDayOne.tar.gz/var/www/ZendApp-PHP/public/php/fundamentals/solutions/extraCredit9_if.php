<html>
<head>
<title>extra credit  9</title>
</head>

<body>

<h1>Extra Credit 9</h1>


		<form action="extraCredit9_if.php" method="get">
			     	
				  <input type="submit" value="throw both dice" name="button" >
		</form>


<?php
	

	if (isset($_REQUEST['button']))  {
			$dice1=rand(1,6);
			$dice2=rand(1,6);
			$total = $dice1 +$dice2;
?>

			dice 1 is:  <?= $dice1 ?> <br>
			dice 2 is:  <?= $dice2 ?> <br>
<?php
		

			if($total==7 || $total==11) {
?>

				YOU WIN!!

<?php			
			}
			else{
				
	?>
			try again!
	<?php	
			}		
	}
	
?>



<br>

</body>
</html>
