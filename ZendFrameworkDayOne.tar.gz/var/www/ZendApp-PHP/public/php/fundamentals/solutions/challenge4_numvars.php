<?php

// This file illustrates the creation and manipulation
// of numeric variables. Numeric variables can be integers or
// real numbers.

$sales      = 190000;

$exp_total          = 30;

?>
<html>
<body>

<h1>Exercise 4: Numeric Variables</h1>




Sales: $<?= $sales ?> dollars <br>

Expenses: $<?= $exp_total  ?> dollars <br>

------<br>

Income: $<?=   $sales - $exp_total ?> dollars


</body>
</html>
