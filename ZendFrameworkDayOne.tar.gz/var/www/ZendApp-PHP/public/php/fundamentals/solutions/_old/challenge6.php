<html>
<?php



$alphabet = "abcdefghijklmnopqrstuvwxyz";

$random_letterA = substr($alphabet,rand(0,25),1);

$random_letterB = substr($alphabet,rand(0,25),1);

$colorString="0123456789abcdef";



$color= substr($colorString,rand(0,15),1).
	substr($colorString,rand(0,15),1).
	substr($colorString,rand(0,15),1).
	substr($colorString,rand(0,15),1).
	substr($colorString,rand(0,15),1).
	substr($colorString,rand(0,15),1)
	;

?>


<?= $random_letterA . strtoupper($random_letterB).rand(0,9).rand(0,9) ?>

<!--body bgcolor="<?= $color ?>" -->

<body style="background-color:   <?= $color ?> ">


</body></html>