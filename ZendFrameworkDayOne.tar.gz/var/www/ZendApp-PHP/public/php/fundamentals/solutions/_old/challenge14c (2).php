<?php
$host     = "localhost";
$user     = "root";
$password = "passwordx";
$database = "northwind";
?>
<html>
<body>
<h1>challenge 14 c</h1>

<?php


$link = mysqli_connect($host, $user  , $password, $database);

if (!$link) {
	   die('Connect Error (' . mysqli_connect_errno() . ') '
	           . mysqli_connect_error());
}

print("Orders for company " . $_REQUEST['compName'] . "<hr>");
$recordset = mysqli_query($link, "SELECT OrderDate FROM $database.Orders WHERE CustomerID='" . $_REQUEST['comId'].  "'");
if($recordset == false) { die('Connect Error (' . mysqli_connect_errno() . ') '
            . mysqli_connect_error());}

while($row = mysqli_fetch_assoc($recordset)) {

		print ($row["OrderDate"] . " order<br>");
}

?>

</body>
</html>