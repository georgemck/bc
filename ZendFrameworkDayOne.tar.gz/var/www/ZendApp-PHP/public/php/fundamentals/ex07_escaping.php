<html>
<body>
<h1>Exercise 7: Escaping Special Characters</h1>

<pre>
<?php

// This file illustrates how special characters such as $ and \
// are handled in print() statements. When your purpose is to
// actually output a $ or \, or a delimiter such as single or
// double quotes, you must treat these special characters so that
// they are not interpreted -- this is known as "escaping" the
// characters.

// wrong!
print("Consult C:\temp\newprices.txt for $SALE values.<hr>");


// corrected
print('Consult C:\temp\newprices.txt for $SALE values.<br>');
print("Consult C:\\temp\\newprices.txt for \$SALE values.<hr>");


// escaping single and double quotes
print('He said "hello" to me' . "\n");
print("He said \"hello\" to me\n<hr>");

print("He said 'hello' to me\n");
print('He said \'hello\' to me and I owe him $BIGBUCKS' . "\n");
?>
</pre>
</body></html>
