<html>
<body>
<h1>Exercise 6: Numeric Functions</h1>

<?php

// This file illustrates the application of math
// functions to numeric variables. These are some of the most
// common numeric functions used in typical PHP scripts.

$alphabet = "abcdefghijklmnopqrstuvwxyz";
$random_letter = substr($alphabet,rand(0,25),1);
?>

<pre> 
sine of pi+1:       <?= sin(pi()+1) ?> 
square root:        <?= sqrt(2) ?> 
random letter:      <?= $random_letter ?> 
floor (truncate):   <?= floor(2.15) ?> 
ceiling (round up): <?= ceil(2.15) ?> 
</pre>
</body></html>
