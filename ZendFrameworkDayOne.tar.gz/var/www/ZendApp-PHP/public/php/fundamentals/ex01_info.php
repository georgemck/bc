<html>
<body>

<h1>Exercise 1: Info about PHP Installation</h1>

<?php

phpinfo();

?>

</body>
</html>