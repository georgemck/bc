<html>
<body>
<h1>Exercise 8: Form Input</h1>

<form action="ex08_form2.php" method="get">


	First Name:     <input type="text" name="firstname"><br>
	Last Name:      <input type="text" name="lastname"><br>
	Favorite Color: <input type="text" name="favorite color"><br>
	Age:            <input type="text" name="age"><br>

				    <input type="submit" value="Send!">


</form>


</body>
</html>
