<?php

// This file illustrates the creation and manipulation
// of numeric variables. Numeric variables can be integers or
// real numbers.

$sales      = 190000;
$exp_rental =  25000;
$exp_salary =  37500;
$exp_supply =    410;
$exp_total          = $exp_rental + $exp_salary + $exp_supply;
$operating_income   = $sales - $exp_total;
$net_income         = $operating_income * 0.60;
?>
<html>
<body>

<h1>Exercise 4: Numeric Variables</h1>


<?php
print("========================================<br>");
print("|             WIDGET COMPANY            <br>");
print("========================================<br>");
print("|   Sales:            $sales            <br>");
print("|   Expenses                            <br>");
print("|     Rental: $exp_rental               <br>");
print("|     Salary: $exp_salary               <br>");
print("|     Supply: $exp_supply               <br>");
print("|             -----                     <br>");
print("|     Total:          $exp_total        <br>");
print("|                     ------            <br>");
print("| Operating income:   $operating_income <br>");
print("|                          ------       <br>");
print("| Income after taxes:      $net_income  <br>");
print("|                                       <br>");
print("========================================<br>");
?>

Net income after taxes: <?= $net_income ?> dollars
</body>
</html>
