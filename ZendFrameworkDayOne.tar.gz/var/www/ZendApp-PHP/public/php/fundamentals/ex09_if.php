<html><head><title>Exercise 9: Conditionals Input</title></head>
<body>
<h1>Exercise 9: Conditionals, Form-Validation and All in One File</h1>

<pre>
	<form action="ex09_if.php" method="get">

	Product SKU: <input type="text" name="sku"> (available SKUs: A125, B109, C100)
	Quantity:    <input type="text" name="quantity" size="2">
			     <input type="submit" value="Order">
	</form>
</pre>


<?php

	// This file illustrates how conditionals are used
	// to choose blocks of code to execute. The condition
	// is placed within parentheses, and the block of
	// code is delimited with French braces.

	extract($_REQUEST);

	if (isset($sku)) {

		$quantity_validation = "ok so far";
		$sku_validation = "ok so far";

		if($quantity < 1){
			$quantity_validation = "You must specify a valid quantity.";
		}

		if($sku == "A125"){
			$price = 12.99;
			$product = "Brass Handles";
		}
		elseif($sku == "B109"){
			$price = 248.17;
			$product = "Pewter Bolts";
		}
		elseif($sku == "C100"){
			$price = 248.17;
			$product = "Iron Hinges";
		}
		else{
			$sku_validation = "SKU not found";
		}


		if($quantity_validation == "ok so far" && $sku_validation == "ok so far") {
			$total = $quantity * $price;
?>
			<pre>
		SKU:       <?= "$sku \n" ?>
		Product:   <?= "$product \n" ?>
		Quantity:  <?= "$quantity \n" ?>
		Price:    $<?= "$price \n" ?>
			  --------
		Total:    $<?= $total ?>
			</pre>

<?php
		}
		else{
			if ($sku_validation != "ok so far"){
?>
				<font color="red"><?= $sku_validation ?></font>
<?php
			}
			if ($quantity_validation != "ok so far"){
?>
				<br>
				<font color="red"><?= $quantity_validation ?></font>
<?php
			}
		}
	}
?>


</body>
</html>
