<?php

// This file illustrates the creation and
// use of associative arrays, also known
// as "hashes". First, the associative
// array is built with "keys" associated
// with "values". Then, a particular
// key is supplied to retrieve the
// corresponding value.
extract($_REQUEST);
extract($_SERVER);
?>

<html><head><title>Exercise 12: Associative Arrays</title></head>
<body>
<h1>Exercise 12: Associative Arrays</h1>

<form action="<?= $PHP_SELF ?>">

Shipper: <select name="shipper">
             <option>Select...</option>
             <option>FedEx</option>
             <option>UPS</option>
             <option>DHL</option>
             <option>USPS</option>
         </select>

         <input type="submit" value="Get Price">

</form>
<?php
if(isset($shipper)==true)
    {
    $price["FedEx"] = 22.23;
    $price["UPS"]   = 14.09;
    $price["DHL"]   = 31.99;
    $price["USPS"]  = 11.54;

	print("<hr>That will cost: \$" . $price[$shipper]);
	}
?>
</body>
</html>