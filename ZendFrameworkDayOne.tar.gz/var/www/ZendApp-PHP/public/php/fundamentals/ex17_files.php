<html>
<body>
<h1>Exercise 17: Working with Files</h1>
<?php
	$host     = "localhost";
	$user     = "root";
	$password = "passwordx";
	$database = "northwind";

	$link = mysqli_connect($host, $user  , $password, $database);

	if (!$link) {
	    die('Connect Error (' . mysqli_connect_errno() . ') '
	            . mysqli_connect_error());
	}

	$recordset = mysqli_query($link, "SELECT * FROM employees");
	if($recordset == false) { die('Connect Error (' . mysqli_connect_errno() . ') '
	            . mysqli_connect_error());}

	$data = "";

	while($row = mysqli_fetch_row($recordset)){
	        $data = $data . $row[0] . '  ';
	        $data = $data . $row[1] . '  ';
	        $data = $data . $row[2] . '  ';
	        $data = $data . $row[3] . '  ';
	        $data = $data . $row[4]  . "\n";
	}

	file_put_contents("ex17_files2.txt", $data);

	$content = file_get_contents("ex17_files2.txt");

	print ($content);

	$content = str_replace("\n", "<br/>", $content);

	print ("<br><br> $content");

?>

</body>
</html>