<?php
class ProductsController extends AppController {

	function index() {
		$this->set('products', $this->Product->find('all'));
	}

	function add() {
		if (!empty($this->data)) {
			if ($this->Product->save($this->data)) {
				$this->Session->setFlash('Your product has been saved.');
				$this->redirect(array('action' => 'index'));
			}
		}
	}

	function delete($id) {
		$this->Product->delete($id);
		$this->Session->setFlash('The product with id: '.$id.' has been deleted.');
		$this->redirect(array('action'=>'index'));
	}

	function edit($id = null) {
		$this->Product->id = $id;
		if (empty($this->data)) {
			$this->data = $this->Product->read();
		} else {
			if ($this->Product->save($this->data)) {
				$this->Session->setFlash('Your post has been updated.');
				$this->redirect(array('action' => 'index'));
			}
		}
	}

}
?>
