<?php
class Product extends AppModel {
	var $validate = array(
		'name' => array('rule' => 'notEmpty'),
		'price' => array('price_rule1' => array('rule' => array('numeric'), 'message' => 'Please enter a price'),
							  'price_rule2' => array('rule' => array('comparison','<=',3), 'message' => 'Please enter a price less than $3'))
	);
}
?>
