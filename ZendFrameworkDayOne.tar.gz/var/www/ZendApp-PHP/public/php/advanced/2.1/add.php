<?php

$db = new mysqli("localhost","phpuser","1234","dollarstore");
$name = $price = "";
extract($_REQUEST);

if (isset($action)) {  
  if (empty($name) || !isset($name))
    $error[] = "Please enter a product name";
  if (!is_numeric($price) || $price < 0 || $price > 3.0)
    $error[] = "Please enter a price less than \$3.0";

  if (!isset($error)) {
    $db->query("INSERT INTO products (name,price) VALUES('$name','$price')");
    header("location: index.php");
  }
}
?>
<html>
<head>
  <title>Add a Product</title>
</head>
<body>
<h1>Add a Product</h1>
<?php if (isset($error)) { 
  foreach ($error as $e) { 
    echo "<p style='color:red'>$e</p>"; 
  }
} ?>
<form method="POST" action="<?php echo $_SERVER["PHP_SELF"]; ?>">
<p>Product Name: <input type="text" name="name" value="<?php echo $name; ?>"/></p>
<p>Price: <input type="text" name="price" value="<?php echo $price; ?>"/></p>
<p><input type="submit" name="action" value="Save Product"/>   
</form>
</body>
</html>