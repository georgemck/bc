<?php
$db = new mysqli("localhost","phpuser","1234","dollarstore");
$db->query("DELETE FROM products WHERE id='".$_REQUEST["id"]."'");
header("location: index.php");
?>
