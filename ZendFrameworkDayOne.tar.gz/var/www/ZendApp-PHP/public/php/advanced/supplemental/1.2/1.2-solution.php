<?php

function display_images($imgs)
{
	foreach ($imgs as $x)
	{
		echo "<img src='img/$x'/><br/>";
	}
}

include("common.php");

htmlStart("Cat Pictures");

display_images(array("cat1.jpg","cat2.jpg","cat3.jpg"));

htmlEnd();

?>

