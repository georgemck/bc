<html>
<body>
<h1>Exercise 28: One or More Occurrences and Lazy Matching</h1>

Yahooo, Kartoo, and Goooogle are search engines!
<hr>
<tt>
<?php
$sentence = "Yahooo, Kartoo, and Goooogle are search engines!";

$result = preg_replace("/o+/", "u", $sentence);
print "replaced /o+/ with a 'u'. Result is '$result'<br>";

$result = preg_replace("/.+/", "oops", $sentence);
print "replaced /.+/ with a 'oops'. Result is '$result'<br>";

$email = "info@academyx.com";
if(preg_match("/.+@.+\.com/", $email))
	{print "$email is valid<br>";} 

$result = preg_replace("/[^ ,!]+/", "blah", $sentence);
print "replaced /[^ ,!]+/ with a 'blah'. Result is '$result'<br>";
?>
</tt>

<h1>Lazy Matching</h1>
Sales: 300 to date, Expenses: 200 to date.
<hr>
<tt>
<?php
$sentence = "Sales: 300 before Xmas, Expenses: 195 after Xmas.";

$result = preg_replace("/Sales: .+ Xmas/", "Sales: 350 before Xmas", $sentence);
print "replaced /Sales: .+ Xmas/ with a 'Sales: 350 before Xmas'. Result is '$result'<br>";

$result = preg_replace("/Sales: .+? Xmas/", "Sales: 350 before Xmas", $sentence);
print "replaced /Sales: .+? Xmas/ with a 'Sales: 350 before Xmas'. Result is '$result'<br>";

?>

</tt>
</body>
</html>
<!--
This is used in the challenge:

$original='<body bgcolor="lightblue">                ' .
          '<img src="line1.gif" width="2"><br>       ' .
          '<img src="line2.gif" width="22"><br>      ' .
          '<img src="line3.gif" width=" 222 "><br>   ' .
          '<table BGCOLOR="beige" width="100">       ';

// Convert the first two image widths to 50 without using | or ?
// Convert all image widths to 50 without using | or ?
// Replace all three image tags and their attributes with single<HR> tags
// Convert both bgcolor attribute values to pink without using |

-->