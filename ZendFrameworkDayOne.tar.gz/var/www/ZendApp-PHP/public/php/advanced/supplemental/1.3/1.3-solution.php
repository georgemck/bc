<?php


if (!mysql_connect('localhost','phpuser','1234'))
	die ("Unable to connect to the MySQL: " . mysql_error());
if (!mysql_select_db('Northwind'))
	die ("Unable to select database: " . mysql_error());

function getProducts()
{
	$result = mysql_query("SELECT ProductName,UnitPrice FROM Products ORDER BY UnitPrice");
	while ($row = mysql_fetch_assoc($result)) {
		$x[$row["ProductName"]] = $row["UnitPrice"];
	}
	return $x;
}
?>

<html>
<body>
<table border="1">
<tr><th>Product Name</th><th>Price</th></tr>
<?php 
$plist = getProducts();
foreach ($plist as $prod=>$price) {
	echo "<tr><td>$prod</td><td>$price</td></tr>";
}
?>
</table>
</body>
</html>

