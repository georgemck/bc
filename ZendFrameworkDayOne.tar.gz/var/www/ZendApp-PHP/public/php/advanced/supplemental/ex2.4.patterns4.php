<html>
<body>
<h1>Exercise 29: Grouping and Returning Matched Patterns</h1>

<tt>
<?php

// using parentheses to group patterns
$email = "info@academyx.com";
if(preg_match("/.+@.+\.(com|net|edu|org|gov)/",$email)) {
	print "$email is valid<br>";
} else {
	print "$email is NOT valid<br>";
}

$song = "Sing 'La la la la do wop do wop do wop la la do wop do la' for us";
if(preg_match("/Sing '(la[ ']|do[ ']|wop[ '])+ for us/i",$song)) {
	print "Valid song<br>";
} else {
	print "NOT valid song<br>";
}




// using parentheses to memorize matched patterns
$email = "My email is info@academyx.com at work.";
preg_match("/(.+)@(.+)\.(com|net|edu|org|gov)/",$email,$matches);
print "Entire pattern matched: $matches[0]<br>";
print "Username:      $matches[1]<br>";
print "Company:       $matches[2]<br>";
print "Domain type:   $matches[3]<br>";



$birth = "November 27, 1968";
preg_match("/(.+) ([0123456789]+), ([0123456789]+)/", $birth, $matches);
$birthmonth = $matches[1];
$birthdate  = $matches[2];
$birthyear  = $matches[3];
print "You were born on $birthmonth $birthdate in $birthyear<br>";


?>
</tt>
</body>
</html>
