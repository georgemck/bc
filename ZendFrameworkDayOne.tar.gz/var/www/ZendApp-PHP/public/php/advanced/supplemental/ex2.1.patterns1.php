<html>
<body>
<h1>Exercise 26: Matching and Replacing Patterns</h1>

The quick brown fox jumped over the lazy dogs.<hr>

<?php
$sentence = "The quick brown fox jumped over the lazy dogs.";

// finding matches:
if(preg_match("/fox/",$sentence) == 1) {
	print "Found one or more foxes in sentence<br>";
} else {
	print "No foxes in $sentence<br>";
}


if(preg_match("/FoX/i",$sentence)) {
	print "Found one or more foxes, ignoring case, in sentence<br>";
} else {
	print "No foxes even when ignoring case differences<br>";
}


if(preg_match("/cat|fly|fox/i",$sentence)) {
	print "Found a cat, fly, or fox, ignoring case, in sentence<br>";
} else {
	print "No cats, flies, or foxes even when ignoring case differences<br>";
}

// doing replacements:
$result = preg_replace("/the/", "your", $sentence);
print "After replacing all 'the' occurrences with 'your': <b>$result</b><br>";

$result = preg_replace("/thE/i", "my", $sentence);
print "After replacing all 'the' occurrences with 'my', ignoring case: <b>$result</b><br>";

$result = preg_replace("/dog|fox/", "accountant", $sentence);
print "After replacing all dogs or foxes with accountants: <b>$result</b><br>";

?>
</body>
</html>