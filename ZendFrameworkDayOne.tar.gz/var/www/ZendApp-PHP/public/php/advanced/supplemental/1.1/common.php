<?php

function htmlStart($title,$charset='ISO-8859-1')
{
	echo "<html>";
	echo "<head>";
	if (!empty($title))
		echo "<title>$title</title>";
	echo "<meta http-equiv='Content-Type' content='text/html;charset=$charset' />";
	echo "</head>";
	echo "<body>";
}

function htmlEnd()
{
	echo "</body></html>";
}

?>

