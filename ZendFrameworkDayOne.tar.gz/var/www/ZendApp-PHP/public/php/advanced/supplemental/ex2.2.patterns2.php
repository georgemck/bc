<html>
<body>
<h1>Exercise 26: Matching and Replacing Patterns</h1>

The rain in spain falls mainly on the plains.
<hr>
<tt>
<?php
$sentence = "The rain in spain falls mainly on the plains.";

// A dot (.) represents any character except a newline. 
$result = preg_replace("/.ain/","hain",$sentence);
print "After replacing /.ain/ with 'hain', result is: <b>$result</b><br>";

// Consecutive dots do not necessary represent the same character match.
$result = preg_replace("/ ...... /"," supposedly ",$sentence);
print "After replacing / ...... / with ' supposedly ', result is: <b>$result</b><br>";


// Escape dots that you want treated verbatim with a backslash 
$email = "info@academyx.com";
if(preg_match("/\.com|\.gov|\.edu|\.net/",$email)) {
	print "$email is valid<br>";
} else {
	print "$email is <b>NOT</b> valid<br>";
}


// A match specifying characters in square brackets indicate that
// any character within the square brackets can be matched.
$result = preg_replace("/[aeiou]/","x",$sentence);
print "After replacing /[aeiou]/ with 'x', result is: <b>$result</b><br>";


// Characters within square brackets that start with a caret indicate any
// character other than the list contained within square brackets.
$result = preg_replace("/[^aei ou]/","x",$sentence);
print "After replacing /[^aei ou]/ with 'x', result is: <b>$result</b><br>";


?>
<tt>
</body>
</html>