<html>
<body>
<h1>Exercise 30: Memorized Patterns in Replacements and Special Symbols</h1>

<tt>
<?php

// using $1, $2, etc. in replacements of memorized patterns
$line  = "";
$line .= "Smith, John, 510-292-2333, San Francisco\n";
$line .= "Jones, Susan, 415-236-6967, Oakland\n";
$result = preg_replace("/(.+?), (.+?), (.+)/","$2, $1, $3", $line);
print "Reversed names: $result<br>";

$sentence = "The quick, brown fox jumped over the lazy dogs.";
$result = preg_replace("/(.)(.+?) /","$2$1ay ", $sentence);
print "Pig latin: $result<br>";


// using symbols to represent any word character, any white space, any digit
$birth = "Dec 16 -- 2001";
preg_match("/(\w+)\s+(\d+)\D+(\d+)/", $birth, $m);
$birthmonth = $m[1];
$birthdate  = $m[2];
$birthyear  = $m[3];
print "He was born on $birthmonth $birthdate in $birthyear<br>";



// using a different pattern delimiter for strings with normal slashes (/)
$url = "http://www.academyx.com";
preg_match("!http://www\.(\w+)\.(\w\w\w)!", $url, $m);
print "Domain: $m[1].$m[2]<br>";
?>
</tt>
</body>
</html>
