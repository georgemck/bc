<?php
include("common.php");
htmlStart("My Home Page");
?>

<h1>Here's where the web page goes.</h1>
<p>Text here.</p>

<?php htmlEnd(); ?>


