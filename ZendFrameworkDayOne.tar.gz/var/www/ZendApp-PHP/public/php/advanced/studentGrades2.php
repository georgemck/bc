<?php

include_once ("studentGrades.php");

class studentGrades2 extends studentGrades {
  public function max()
  {
    return max($this->grades);
  }
  public function min()
  {
    return min($this->grades);
  }
}

?>
