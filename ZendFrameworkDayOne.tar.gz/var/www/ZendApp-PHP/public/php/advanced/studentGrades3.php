<?php
include_once("studentGrades2.php");

class studentGrades3 extends studentGrades2 {
  public function __toString()
  {
    return $this->title . ". Average: " . $this->avg();
  }
}

?>
