<?php
if (!mysql_connect('192.168.0.4','studentx','passwordx'))
	die ("Unable to connect to the MySQL: " . mysql_error());
if (!mysql_select_db('northwind'))
	die ("Unable to select database: " . mysql_error());

// 1. Was the submit button pressed
if (isset($_REQUEST["action"])) {

	// 2. Validate input fields
	if (is_numeric($_REQUEST["maxprice"])) {

		// 3. Everything is OK, build and run query
		$sup="";
		if ($_REQUEST["supplier"] != 0)
			$sup = "SupplierID=".$_REQUEST["supplier"]." AND ";
		$query = "SELECT ProductName,UnitPrice FROM Products WHERE $sup UnitPrice < ".
			$_REQUEST["maxprice"] . " ORDER BY UnitPrice DESC";
		$result = mysql_query($query);
		// 4. Output data
		echo "<html><body><table>\n";
		while ($row = mysql_fetch_assoc($result))
			echo "<tr><td>".$row["ProductName"]."</td><td>".$row["UnitPrice"]."</td></tr>\n";
		echo "</table></body></html>\n";
		exit;
	}
}
?>
<html>
<head>
<title></title>
</head>
<body>
<h1>Northwind Product Listing</h1>
<p>Select a supplier and then enter a maximum product price to get a product listing.</p>
<form method="GET" action="<?php echo $_SERVER["PHP_SELF"];?>">
<p>Supplier:
<select name="supplier">
<option value="0">All Suppliers</option>
<?php
$result = mysql_query("SELECT SupplierID,CompanyName FROM Suppliers");
while ($row = mysql_fetch_assoc($result)) {
	echo "<option value=\"" . $row["SupplierID"] . "\">" . $row["CompanyName"] . "</option>\n";
}
?>
</select></p>
<p>Maximum Price: <input type="text" name="maxprice"></p>
<p><input type="submit" name="action" value="Submit"/></p>
</form>
</body>
</html>
