<?php
if (!mysql_connect('192.168.0.4','studentx','passwordx'))
	die ("Unable to connect to the MySQL: " . mysql_error());
if (!mysql_select_db('northwind'))
	die ("Unable to select database: " . mysql_error());
?>
<html>
<head>
<title></title>
</head>
<body>
<h1>Northwind Product Listing</h1>
<p>Select a supplier and then enter a maximum product price to get a product listing.</p>
<form method="GET" action="<?php echo $_SERVER["PHP_SELF"];?>">
<p>Supplier:
<select name="supplier">
<option value="0">All Suppliers</option>
<?php
$result = mysql_query("SELECT SupplierID,CompanyName FROM Suppliers");
while ($row = mysql_fetch_assoc($result)) {
	echo "<option value=\"" . $row["SupplierID"] . "\">" . $row["CompanyName"] . "</option>\n";
}
?>
</select></p>
<p>Maximum Price: <input type="text" name="maxprice"></p>
<p><input type="submit" name="action" value="Submit"/></p>
</form>
</body>
</html>
