<?php

class studentGrades {
  public $title;
  public $grades;
  
  public function setCourseTitle($className)
  {
    $this->title = $className;
  }
  
  public function addGrade($g)
  {
    $this->grades[] = $g;
  }
  
  public function avg()
  {
    $sum = 0;
    foreach ($this->grades as $x) {
        $sum += $x;
    }
    if (count($this->grades) > 0) {
      return $sum/count($this->grades);
    } else {
      return 0;
    }
  }
}

?>
