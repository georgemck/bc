<?php
if (!mysql_connect('localhost','phpuser','1234'))
	die ("Unable to connect to the MySQL: " . mysql_error());
if (!mysql_select_db('Northwind'))
	die ("Unable to select database: " . mysql_error());

// 1. Was the submit button pressed
if (isset($_REQUEST["action"])) {

	// 2. Validate input fields
	if (!empty($_REQUEST["productname"])) {
		
		// 3. Everything is OK, build and run query
		$query = "SELECT * FROM Products WHERE ProductName='".$_REQUEST["productname"]."'";
		$result = mysql_query($query);
		// 4. Output data
		
		if (mysql_num_rows($result) > 0) {
			echo "<html><body><table border=1>\n";
			echo "<tr><th>Product Name</th><th>Unit Price</th><th>Units in Stock</th></tr>\n";
			while ($row = mysql_fetch_assoc($result))
				echo "<tr><td>".$row["ProductName"]."</td><td>".$row["UnitPrice"]."</td><td>".
					$row["UnitsInStock"]. "</td></tr>\n";
			echo "</table></body></html>\n";
			exit;
		} else {
			//5a. Error. can't find the product name
			$error = "The product you entered could not be found in the database. Please check your spelling.";
		}
	} else {
		// 5a. Error. They entered a blank in the product name field
		$error = "Please enter a product name.";
	}
}
?>
<html>
<head>
<title></title>
</head>
<body>
<h1>Northwind Product Listing</h1>
<?php 
// 5b. Output error message at the top of the page
if (isset($error)) 
	echo "<p style='color:red'>$error</p>";
?>
<p>Enter the product name to find out the number of units available and the unit price.</p>
<form method="GET" action="<?php echo $_SERVER['PHP_SELF'];?>">
<?php
// 6. Make sure to preserve product name for entry again if it wasn't found.
$pval = (isset($_REQUEST["productname"])) ? $_REQUEST["productname"] : "";
?>
<p><input type="text" name="productname" value="<?php echo $pval; ?>"/></p>
<p><input type="submit" name="action" value="Submit"/></p>
</form>
</body>
</html>
