<?php
// challenge 2.5

if (!mysql_connect('localhost','phpuser','1234'))
	die ("Unable to connect to the MySQL: " . mysql_error());
if (!mysql_select_db('users'))
	die ("Unable to select database: " . mysql_error());
	
function storeUser($username,$name,$pwd)
{
  if (userExists($username))
    return false;
  mysql_query("INSERT INTO users (username,name,pwd) VALUES ('$username','$name','$pwd')");
}

function listUsers()
{
  $result = mysql_query("SELECT * FROM users");
  while ($row = mysql_fetch_assoc($result)) {
    $ans[] = $row["name"];
  }
  return $ans;
}

function editUser($username,$newName,$newPwd)
{
  return mysql_query("UPDATE users SET name='$newName',pwd='$newPwd' WHERE username='$username'")
}

function deleteUser($username)
{
  return mysql_query("DELETE FROM users WHERE username='$username'");
}

function userExists($username)
{
  $result = mysql_query("SELECT * FROM users WHERE username='".$username."'");
  return (mysql_num_rows($result) > 0);
}

?>
