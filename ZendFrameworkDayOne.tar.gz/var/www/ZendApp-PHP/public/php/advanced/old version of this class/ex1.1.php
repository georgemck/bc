<?php
//if (!mysql_connect('192.168.0.4','studentx','passwordx'))
if (!mysql_connect('localhost','root','passwordx'))
	die ("Unable to connect to the MySQL: " . mysql_error());
if (!mysql_select_db('northwind'))
	die ("Unable to select database: " . mysql_error());
if (!($result = mysql_query("SELECT * FROM Employees")))
	die ("Unable to issue query: " . mysql_error());
?>
<html>
<body>
<h1>List of Employees</h1>
<ol>
<?php
if (mysql_num_rows($result) == 0)
	echo "No employees\n";

while ($row = mysql_fetch_assoc($result)) {
	echo "<li>".$row["FirstName"]." ".$row["LastName"]."</li>\n";
}
?>
</ol>
</body>
</html>
